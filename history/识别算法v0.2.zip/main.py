import numpy as np
import os
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from collections import  Counter
import time

train_path = 'train'
test_path = 'test'
caiyang = 1000
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def new_report(test_report,length = 3):
    lists = os.listdir(test_report)                                    #列出目录的下所有文件和文件夹保存到lists
    if length>len(lists):
        length = len(lists)
    lists.sort(key=lambda fn:os.path.getmtime(test_report + "/" + fn))#按时间排序
    file_new = lists[-length:]                   #获取最新的文件保存到file_new
    file_new = list(map(lambda fn:test_report + "/" + fn,file_new))
    return file_new


def get_train_file_list(train_path):
    train_dic = {}
    trian_file_lists = os.listdir(train_path)
    for trian_file in trian_file_lists:
        if not os.path.isdir(train_path+'/'+trian_file):  # 排除非文件夹的文件
            trian_file_lists.remove(trian_file)
        else:
            file_content_data_list = list(map(lambda fn: train_path + "/" + trian_file + "/" +fn
                                              ,os.listdir(train_path+'/'+trian_file)))
            train_dic[trian_file] = file_content_data_list
    return train_dic





def gen_pre(filedata,index = 0):
    content = filedata[:, 1:]
    kmeans = KMeans(n_clusters=2).fit(content)
    pred = kmeans.predict(content)  # 0为背景，index+1为有效信号
    pred_pretime = pred[pred.shape[0] // 3:pred.shape[0]*2 // 3]
    if Counter(pred_pretime)[1] >= Counter(pred_pretime)[0]:  # 默认中间1/5时间内信号多于背景
        pred = (index + 1) * pred
    else:
        pred = -(index + 1) * (pred - 1)
    print(len(pred),Counter(pred)[index + 1])
    return pred

train_file_path="train"  #训练目录地址
test_file_path="test"  #训练目录地址

# train_file_list = new_report(train_file_path,5)

train_dic = get_train_file_list(train_path)

test_file_list = new_report(test_file_path,1)

print('训练用数据',train_dic)    #有待优化输出
print('测试用数据',test_file_list)
# test_file_list = [test_file_path + '/咖啡3号.txt']  #测试用

for index,files in enumerate(train_dic):
    for file in train_dic[files]:
        filedata = np.genfromtxt(file, delimiter='	')
        pred = gen_pre(filedata,index)
        filedata[:, 0] = pred
        try:
            traindata = np.append(traindata, filedata, axis=0)
        except:
            traindata = filedata


for index,file in enumerate(test_file_list):
    filedata = np.genfromtxt(file, delimiter='	')
    filedata[:, 0] = -index #随便写点啥
    try:
        testdata = np.append(testdata, filedata, axis=0)
    except:
        testdata = filedata





y_train=traindata[:,0].astype(int)
x_train=traindata[:,1:]
x_test = testdata[:,1:]

print('打标结束')
scaler = StandardScaler()
x_trainstd = scaler.fit_transform(x_train)  # 标准化
x_teststd = scaler.transform(x_test)
print('加载数据结束，开始svm拟合')
time_start=time.time()
clf = SVC(probability=True)
clf.fit(x_trainstd, y_train)
# 训练模型

# 计算测试集精度
pre = clf.predict(x_teststd)
time_end=time.time()
print('totally cost',time_end-time_start)
print('拟合结束，开始绘图')

#以下绘图测试
estimator = PCA(n_components=2)
content_pca = estimator.fit_transform(x_trainstd)
test_content_pca = estimator.transform(x_teststd)


fig = plt.figure()
# ax = fig.add_subplot(121)
# s = 4
# c_list = ['k','c','g','b','y','m']
# marker_list = ['.','>','<','^','v','x']
# beijing_index = np.argwhere(y_train == 0)
#
# a = np.arange(len(beijing_index))
# np.random.shuffle(a)
# beijing_index = beijing_index[a[:min(len(beijing_index),caiyang)]]
#
# ax.scatter(content_pca[beijing_index, 0], content_pca[beijing_index, 1], c=c_list[0],
#                marker=marker_list[0], alpha=0.3, label=str(0),s=s)
# for index in range(1,len(train_dic)+1):
#     xinhao_index = np.argwhere(y_train == index)
#
#     a = np.arange(len(xinhao_index))
#     np.random.shuffle(a)
#     xinhao_index = xinhao_index[a[:min(len(xinhao_index), caiyang)]]
#
#     ax.scatter(content_pca[xinhao_index, 0], content_pca[xinhao_index, 1], c=c_list[index],
#                marker=marker_list[index], alpha=0.3, label=str(index),s=s)
#     print(index,len(xinhao_index))
#
# ax.scatter(test_content_pca[:,0], test_content_pca[:,1], c='r', marker='o',label = 'test',s = s)
# plt.legend( loc = 0, ncol = 2)


ax1 = fig.add_subplot(111)
ax1.set_yticks(range(len(train_dic)+1))
ax1.set_yticklabels(['空气']+list(train_dic.keys()), rotation=30, fontsize='small')
time = np.arange(len(pre))
plt.plot(time, pre)
# python要用show展现出来图


plt.show()
print(95279527)