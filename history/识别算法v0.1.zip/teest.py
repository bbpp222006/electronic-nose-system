import numpy as np
import os
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from collections import  Counter


filedata = np.genfromtxt('train/4号.txt', delimiter='	')
x_train = filedata[:,1:]
scaler = StandardScaler()
x_train = scaler.fit_transform(x_train)


estimator = PCA(n_components=2)
content_pca = estimator.fit_transform(x_train)


estimator = KMeans(n_clusters=2)#构造聚类器
estimator.fit(x_train)#聚类
label_pred = estimator.labels_ #获取聚类标签
#绘制k-means结果
x0 = content_pca[label_pred == 0]
x1 = content_pca[label_pred == 1]


fig = plt.figure()
ax = fig.add_subplot(121)

ax.scatter(np.argwhere(label_pred == 0), np.ones(len(np.argwhere(label_pred == 0))), c = "red", marker='o', label='label0')
ax.scatter(np.argwhere(label_pred == 1), np.zeros(len(np.argwhere(label_pred == 1))), c = "green", marker='*', label='label1')
plt.legend(loc=2)


ax1 = fig.add_subplot(122)
ax1.scatter(x0[:, 0], x0[:, 1], c = "red", marker='o', label='label0')
ax1.scatter(x1[:, 0], x1[:, 1], c = "green", marker='*', label='label1')
plt.legend(loc=2)


plt.show()