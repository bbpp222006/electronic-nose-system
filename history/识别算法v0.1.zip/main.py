import numpy as np
import os
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from collections import  Counter


def new_report(test_report,length = 3):
    lists = os.listdir(test_report)                                    #列出目录的下所有文件和文件夹保存到lists
    if length>len(lists):
        length = len(lists)
    lists.sort(key=lambda fn:os.path.getmtime(test_report + "/" + fn))#按时间排序
    file_new = lists[-length:]                   #获取最新的文件保存到file_new
    file_new = list(map(lambda fn:test_report + "/" + fn,file_new))
    return file_new


def gen_pre(filedata,index = 0):
    content = filedata[:, 1:]
    kmeans = KMeans(n_clusters=2).fit(content)
    pred = kmeans.predict(content)  # 0为背景，index+1为有效信号
    pred_pretime = pred[pred.shape[0] // 3:pred.shape[0]*2 // 3]
    if Counter(pred_pretime)[1] >= Counter(pred_pretime)[0]:  # 默认中间1/5时间内信号多于背景
        pred = (index + 1) * pred
    else:
        pred = -(index + 1) * (pred - 1)
    print(len(pred),Counter(pred)[index + 1])
    return pred

train_file_path="train"  #训练目录地址
test_file_path="test"  #训练目录地址

train_file_list = new_report(train_file_path,5)
test_file_list = new_report(test_file_path,1)
print('训练用数据',train_file_list)
print('测试用数据',test_file_list)
# test_file_list = [test_file_path + '/咖啡3号.txt']  #测试用

for index,file in enumerate(train_file_list):
    filedata = np.genfromtxt(file, delimiter='	')
    pred = gen_pre(filedata,index)
    filedata[:, 0] = pred
    try:
        traindata = np.append(traindata, filedata, axis=0)
    except:
        traindata = filedata

for index,file in enumerate(test_file_list):
    filedata = np.genfromtxt(file, delimiter='	')
    filedata[:, 0] = -index #随便写点啥
    try:
        testdata = np.append(testdata, filedata, axis=0)
    except:
        testdata = filedata





y_train=traindata[:,0].astype(int)
x_train=traindata[:,1:]
x_test = testdata[:,1:]

print('打标结束')
scaler = StandardScaler()
x_trainstd = scaler.fit_transform(x_train)  # 标准化
x_teststd = scaler.transform(x_test)
print('加载数据结束，开始svm拟合')

clf = SVC(probability=True)
clf.fit(x_trainstd, y_train)
# 训练模型

# 计算测试集精度
pre = clf.predict(x_teststd)
print('拟合结束，开始绘图')

#以下绘图测试
estimator = PCA(n_components=2)
content_pca = estimator.fit_transform(x_trainstd)
test_content_pca = estimator.transform(x_teststd)


fig = plt.figure()
ax = fig.add_subplot(121)
s = 4
c_list = ['k','c','g','b','y','m']
marker_list = ['.','>','<','^','v','x']
beijing_index = np.argwhere(y_train == 0)

for index in range(len(train_file_list)+1):
    xinhao_index = np.argwhere(y_train == index)
    ax.scatter(content_pca[xinhao_index, 0], content_pca[xinhao_index, 1], c=c_list[index],
               marker=marker_list[index], alpha=0.3, label=str(index),s=s)
    print(index,len(xinhao_index))

ax.scatter(test_content_pca[:,0], test_content_pca[:,1], c='r', marker='o',label = 'test',s = s)
plt.legend( loc = 0, ncol = 2)


ax1 = fig.add_subplot(122)
time = np.arange(len(pre))
plt.plot(time, pre)
# python要用show展现出来图


plt.show()
print(95279527)